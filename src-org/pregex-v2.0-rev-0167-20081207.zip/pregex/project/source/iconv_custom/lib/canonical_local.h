  (int)(long)&((struct stringpool_t *)0)->stringpool_str179,
  (int)(long)&((struct stringpool_t *)0)->stringpool_str505,
