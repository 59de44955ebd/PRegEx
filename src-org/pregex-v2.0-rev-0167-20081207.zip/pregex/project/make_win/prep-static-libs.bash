#!/bin/sh

# pull in the MinGW libraries needed for static linking locally

echo " --- $0 ---"

PRGLOC="`cd $(dirname $0)/../..;pwd`"
OBJLOC="${PRGLOC}/build_win/mingw.build"

echo "${PRGLOC}"
echo "${SRCLOC}"
echo "${OBJLOC}"

if [ ! -d "${OBJLOC}" ]; then
	mkdir -vp "${OBJLOC}"
fi

echo "copying over needed libraries ..."
# libgcc.a
cp -v `gcc -print-libgcc-file-name` "${OBJLOC}"

# libmingwex.a
cp -v `gcc -print-file-name=libmingwex.a` "${OBJLOC}"

ls -l "${OBJLOC}/"

