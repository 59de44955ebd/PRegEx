#!/bin/sh

# extract director 11 xdk from zip file

echo " --- $0 ---"

#PRGLOC=`perl -e "print(((qq{$0}=~m{(.*)/project\b})[0] || (qx{pwd}=~m{(.*)/project\b})[0]) or die)"`
# msys 1.0.10 only has bash 2.04 and no perl
PRGLOC="`cd $(dirname $0)/../..;pwd`"
SRCLOC="${PRGLOC}/xdk11_win"
DISTFILE="${PRGLOC}/project/packages/xdk11_win.zip"

UNZIP="`cd $(dirname $0);pwd`/unzip.exe"

echo "${PRGLOC}"
echo "${SRCLOC}"
echo "${DISTFILE}"
echo "${UNZIP}"


if [ ! -d "${SRCLOC}" ]; then
	echo "extracting source file ..."
	cd "${PRGLOC}"
	${UNZIP} "${DISTFILE}" -d "${SRCLOC}"
else
	echo "xdk already extracted, exiting ..."
	exit
fi

cd "${SRCLOC}"
ls -l "${SRCLOC}/"

