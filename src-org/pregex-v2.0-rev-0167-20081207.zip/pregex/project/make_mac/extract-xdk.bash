#!/bin/bash

# extract director 11 xdk from zip file

echo " --- $0 ---"

PRGLOC="`cd $(dirname $0)/../..;pwd`"
SRCLOC="${PRGLOC}/xdk11_mac"
DISTFILE="${PRGLOC}/project/packages/xdk11_mac.zip"

echo "${PRGLOC}"
echo "${SRCLOC}"
echo "${DISTFILE}"

if [ ! -d "${SRCLOC}" ]; then
	echo "extracting source file ..."
	cd "${PRGLOC}"
	unzip "${DISTFILE}"
else
	echo "xdk already extracted, exiting ..."
	exit
fi

# remove crud left behind by sloppy Mac XDK zip
rm -rf "${PRGLOC}/__MACOSX"
find "${SRCLOC}" -name .DS_Store -exec rm {} \;

cd "${SRCLOC}"
ls -l "${SRCLOC}/"

